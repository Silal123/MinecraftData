import os, sys

contents = open('aaa_master.template').read()

for filename in os.listdir('./'):
    if filename.endswith(".json"):
        with open(filename, 'w') as f:
            f.write(contents)
            print('[COPY] succesfull!')
    else:
        continue
